/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author ADMIN
 */
public class Q_2 {
    public int fact(int a){
        int fac=1;
        for(int i = 1;i<=a;i++){
            fac *= i;
        }
        return fac;
    }
}
